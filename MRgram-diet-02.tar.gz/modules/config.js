/**
 * MRgram — config.js (Supabase)
 * Bitta Supabase client + state + Firestore-uslubidagi ma'lumotni
 * (camelCase, createdAt.toMillis()) Supabase qatorlaridan yasovchi mapperlar.
 * Mapperlar qolgan modullarni bosqichma-bosqich ko'chirish imkonini beradi.
 */

import { createClient } from 'https://cdn.jsdelivr.net/npm/@supabase/supabase-js@2.39.3/+esm';

// URL va anon key modules/env.js dan keladi — uni Vercel build (scripts/build-env.mjs)
// Environment Variables'dan yozadi. service_role ni BU YERGA YOZMANG.
import { SUPABASE_URL, SUPABASE_ANON_KEY } from './env.js';
export { SUPABASE_URL, SUPABASE_ANON_KEY };
export const MEDIA_BUCKET      = 'media';

export const SB_CONFIGURED = !/YOUR-/.test(SUPABASE_URL + SUPABASE_ANON_KEY);
if (!SB_CONFIGURED) {
  console.error('⚠️ config.js: SUPABASE_URL va SUPABASE_ANON_KEY hali kiritilmagan');
}

export const sb = createClient(SUPABASE_URL, SUPABASE_ANON_KEY, {
  auth: {
    persistSession: true,
    autoRefreshToken: true,
    detectSessionInUrl: false,
    storageKey: 'mrgram-auth',
  },
  realtime: { params: { eventsPerSecond: 10 } },
});

/* ── Vaqt: Firestore Timestamp'ga o'xshash (toMillis/toDate) ────────── */
class Ts {
  constructor(ms) {
    this.seconds = Math.floor(ms / 1000);
    this.nanoseconds = (ms % 1000) * 1e6;
  }
  toMillis() { return this.seconds * 1000 + Math.floor(this.nanoseconds / 1e6); }
  toDate()   { return new Date(this.toMillis()); }
  toISOString() { return new Date(this.toMillis()).toISOString(); }
}
/** ISO string | ms | Date → Ts (yoki null) */
export function ts(v) {
  if (v == null || v === '') return null;
  const ms = typeof v === 'number' ? v : (v instanceof Date ? v.getTime() : Date.parse(v));
  return Number.isNaN(ms) ? null : new Ts(ms);
}
/** Ts | ms | Date | ISO → ISO string (DB'ga yozish uchun) */
export function toIso(v) {
  const t = ts(typeof v === 'object' && v?.toMillis ? v.toMillis() : v);
  return t ? t.toISOString() : null;
}

/* ── Storage ─────────────────────────────────────────────────────────── */
export function mediaPublicUrl(path) {
  if (!path) return null;
  return sb.storage.from(MEDIA_BUCKET).getPublicUrl(path).data.publicUrl;
}

/* ── Mapperlar (DB qatori → eski Firestore ko'rinishi) ──────────────── */
export function mapProfile(r) {
  if (!r) return null;
  return {
    uid: r.id, id: r.id,
    username: r.username,
    fullName: r.full_name || '',
    email: r.email || null,
    bio: r.bio || '',
    avatar: r.avatar || '',
    coverUrl: r.cover_url || null,
    website: r.website || '',
    location: r.location || '',
    approval: r.approval,
    approved: r.approval === 'approved' ? true : (r.approval === 'rejected' ? 'rejected' : false),
    blocked: r.blocked === true,
    blockedUntil: ts(r.blocked_until),
    isAdmin: r.is_admin === true,
    lastSeenAt: ts(r.last_seen),
    lastLoginAt: ts(r.last_login),
    lastUserAgent: r.last_user_agent || null,
    lastPlatform: r.last_platform || null,
    createdAt: ts(r.created_at),
  };
}

export function mapPost(r) {
  if (!r) return null;
  return {
    id: r.id,
    userId: r.user_id,
    userFullName: r.user_full_name || '',
    text: r.text,
    mediaPath: r.media_path,
    mediaUrl: mediaPublicUrl(r.media_path),
    mediaType: r.media_type,
    mediaWidth: r.media_width,
    mediaHeight: r.media_height,
    fileName: r.file_name,
    fileSize: r.file_size,
    isPublic: r.is_public === true,
    isMaxPrivate: r.is_max_private === true,
    views: r.views || 0,
    likes: r.likes_count || 0,
    commentCount: r.comment_count || 0,
    createdAt: ts(r.created_at),
  };
}

/** Post uchun media URL (mapPost allaqachon mediaUrl beradi) */
export async function getMediaUrl(post) {
  if (post.mediaUrl) return post.mediaUrl;
  return mediaPublicUrl(post.mediaPath);
}

/**
 * Faylni 'media' bucket'ga yuklash. Yo'l: {uid}/{folder}/{vaqt}_{nom}
 * (storage policy birinchi papka = auth.uid() bo'lishini talab qiladi)
 */
export async function uploadViaController(file, folder = 'posts') {
  if (!state.me) throw new Error('Tizimga kirilmagan');
  const safeName = file.name.replace(/[^\w.\-]/g, '_').replace(/_+/g, '_');
  const path = `${state.me.uid}/${folder}/${Date.now()}_${(crypto.randomUUID ? crypto.randomUUID() : Math.random().toString(36).slice(2) + Math.random().toString(36).slice(2))}_${safeName}`;
  const { data, error } = await sb.storage.from(MEDIA_BUCKET).upload(path, file, {
    contentType: file.type || 'application/octet-stream',
    upsert: false,
  });
  if (error) { console.error('❌ Storage:', error); throw error; }
  return { path: data.path, url: mediaPublicUrl(data.path) };
}

/** Katta jadvalni sahifalab to'liq oladi (PostgREST 1000 qatordan ortiq bermaydi) */
export async function fetchAllRows(table, columns = '*', orderCol = 'created_at') {
  const PAGE = 1000, out = [];
  for (let from = 0; ; from += PAGE) {
    const { data, error } = await sb.from(table).select(columns)
      .order(orderCol, { ascending: false }).range(from, from + PAGE - 1);
    if (error) throw error;
    out.push(...(data || []));
    if (!data || data.length < PAGE) break;
  }
  return out;
}

/** 'media' bucket'dagi {uid}/... fayllarini o'chiradi (best-effort; egasi yoki admin) */
export async function purgeUserMedia(uid) {
  if (!uid) return;
  const bucket = sb.storage.from(MEDIA_BUCKET);
  const walk = async (prefix, depth) => {
    const out = [];
    const { data } = await bucket.list(prefix, { limit: 1000 });
    for (const it of data || []) {
      const path = `${prefix}/${it.name}`;
      if (it.id) out.push(path);                                    // fayl
      else if (depth < 3) out.push(...await walk(path, depth + 1)); // papka
    }
    return out;
  };
  try {
    const files = await walk(uid, 0);
    for (let i = 0; i < files.length; i += 100) await bucket.remove(files.slice(i, i + 100));
  } catch (e) {
    console.warn('[Media] Tozalanmadi:', e?.message);
  }
}

// Constants
export const MAX_FILE = 50 * 1024 * 1024;
export const CAP_LIMIT = 100;

/** Joriy foydalanuvchi admin (profiles.is_admin) */
export function isAdmin() {
  return !!(state.me && state.me.isAdmin);
}

// State
export const state = {
  me: null, allPosts: [], tab: 'all', search: '', view: 'home',
  selFile: null, _objUrl: null, visibleN: 10, loadingMore: false,
  reelObs: null, viewedSet: new Set(),
  myLikedPosts: new Set(), _knownUnliked: new Set(), cmtPostId: null,
  pendingReelId: null, pendingReelTime: 0, _lastPostIds: '',
  currentChatUid: null, currentChatId: null,
  globalMuted: true, currentViewingUserId: null,
  currentViewingUserPosts: [], feedVidObs: null, viewObserver: null,
  _userCache: {},         // uid -> { fullName, avatar, ... }
  _likeStatusCache: {},   // postId -> boolean (liked/unliked)
};

/** Parolni tekshirish — asosiy sessiyaga tegmaydi (alohida vaqtinchalik client) */
export async function verifyPassword(email, password) {
  const tmp = createClient(SUPABASE_URL, SUPABASE_ANON_KEY, {
    auth: { persistSession: false, autoRefreshToken: false, detectSessionInUrl: false, storageKey: 'mrgram-verify' },
  });
  const { error } = await tmp.auth.signInWithPassword({ email, password });
  if (error) {
    const e = new Error(error.message);
    e.code = /invalid login credentials/i.test(error.message) ? 'wrong-password' : (error.code || 'auth-error');
    throw e;
  }
  await tmp.auth.signOut({ scope: 'local' }).catch(() => {});
  return true;
}

/** chats qatori (+ chat_members embed) → eski Firestore ko'rinishi */
export function mapChat(r) {
  if (!r) return null;
  const unread = {}, typing = {};
  (r.chat_members || []).forEach(m => {
    unread[m.user_id] = m.unread_count || 0;
    typing[m.user_id] = !!m.typing_until;
  });
  return {
    id: r.id,
    participants: [r.user_a, r.user_b],
    lastMessage: r.last_message || '',
    lastSenderId: r.last_sender_id || null,
    lastMessageAt: ts(r.last_message_at),
    unreadCount: unread,
    typing,
    createdAt: ts(r.created_at),
  };
}

/** messages qatori → eski Firestore ko'rinishi */
export function mapMessage(r) {
  if (!r) return null;
  return {
    id: r.id,
    chatId: r.chat_id,
    senderId: r.sender_id,
    type: r.type,
    text: r.text || '',
    mediaPath: r.media_path,
    mediaUrl: mediaPublicUrl(r.media_path) || '',
    mediaType: r.media_type,
    fileName: r.file_name,
    fileSize: r.file_size,
    duration: r.duration,
    status: r.status,
    readAt: ts(r.read_at),
    editedAt: ts(r.edited_at),
    createdAt: ts(r.created_at),
  };
}

/** groups qatori (+ group_members embed) → eski Firestore ko'rinishi */
export function mapGroup(r) {
  if (!r) return null;
  const members = [], adminIds = [], unread = {};
  (r.group_members || []).forEach(m => {
    members.push(m.user_id);
    unread[m.user_id] = m.unread_count || 0;
    if (m.role === 'owner' || m.role === 'admin') adminIds.push(m.user_id);
  });
  return {
    id: r.id,
    type: r.type,
    name: r.name,
    avatar: r.avatar || '',
    description: r.description || '',
    ownerId: r.owner_id,
    adminIds,
    members,
    isPrivate: r.is_private === true,
    inviteCode: r.invite_code || null,
    username: (r.type === 'channel' && !r.is_private) ? (r.invite_code || '') : '',
    msgPermission: r.msg_permission || 'all',
    lastMessage: r.last_message || '',
    lastSenderId: r.last_sender_id || null,
    lastMessageAt: ts(r.last_message_at),
    unreadCount: unread,
    subscriberCount: members.length,
    createdAt: ts(r.created_at),
  };
}
