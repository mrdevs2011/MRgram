import { sb, state, MAX_FILE, uploadViaController } from './config.js';
import { $, esc, fmtSz, lockScroll, unlockScroll, defAvi } from './utils.js';
import { toast }                                   from './toast.js';

/* ═══════════════════════════════════════════════════════════════════════
   FILE TYPE → SVG icon + label + accent color
   ═══════════════════════════════════════════════════════════════════════ */
function getFileTypeInfo(name = '', mime = '') {
  const ext = (name.split('.').pop() || '').toLowerCase();
  const m   = (mime || '').toLowerCase();

  /* ── Audio / Music ── */
  if (m.startsWith('audio') || ['mp3','wav','ogg','aac','flac','m4a','wma','opus','aiff','mid','midi'].includes(ext))
    return {
      label: ext.toUpperCase() || 'AUDIO', color: '#ffffff',
      svg: `<svg viewBox="0 0 48 48" fill="none" xmlns="http://www.w3.org/2000/svg">
        <rect width="48" height="48" rx="10" fill="rgba(255, 255, 255,0.12)"/>
        <path d="M18 34V18l16-4v16" stroke="#ffffff" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"/>
        <circle cx="15" cy="34" r="3" fill="#ffffff"/>
        <circle cx="31" cy="30" r="3" fill="#ffffff"/>
        <path d="M20 22l12-3" stroke="#ffffff" stroke-width="1.6" stroke-linecap="round" opacity=".5"/>
      </svg>`
    };

  /* ── HTML ── */
  if (['html','htm'].includes(ext) || m === 'text/html')
    return {
      label: 'HTML', color: '#f97316',
      svg: `<svg viewBox="0 0 48 48" fill="none" xmlns="http://www.w3.org/2000/svg">
        <rect width="48" height="48" rx="10" fill="rgba(249,115,22,0.12)"/>
        <text x="24" y="29" text-anchor="middle" font-family="monospace" font-weight="700" font-size="10" fill="#f97316">&lt;/&gt;</text>
        <path d="M14 18l-5 6 5 6" stroke="#f97316" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"/>
        <path d="M34 18l5 6-5 6" stroke="#f97316" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"/>
        <line x1="28" y1="14" x2="20" y2="34" stroke="#f97316" stroke-width="2" stroke-linecap="round" opacity=".6"/>
      </svg>`
    };

  /* ── TypeScript ── */
  if (['ts','tsx'].includes(ext))
    return {
      label: 'TS', color: '#ffffff',
      svg: `<svg viewBox="0 0 48 48" fill="none" xmlns="http://www.w3.org/2000/svg">
        <rect width="48" height="48" rx="10" fill="rgba(255, 255, 255,0.12)"/>
        <rect x="10" y="10" width="28" height="28" rx="5" fill="#ffffff"/>
        <text x="24" y="30" text-anchor="middle" font-family="monospace" font-weight="800" font-size="14" fill="white">TS</text>
      </svg>`
    };

  /* ── JavaScript / JSX ── */
  if (['js','mjs','cjs','jsx'].includes(ext) || m.includes('javascript'))
    return {
      label: ext === 'jsx' ? 'JSX' : 'JS', color: '#eab308',
      svg: `<svg viewBox="0 0 48 48" fill="none" xmlns="http://www.w3.org/2000/svg">
        <rect width="48" height="48" rx="10" fill="rgba(234,179,8,0.12)"/>
        <rect x="10" y="10" width="28" height="28" rx="5" fill="#eab308"/>
        <text x="24" y="30" text-anchor="middle" font-family="monospace" font-weight="800" font-size="${ext==='jsx'?'10':'14'}" fill="currentColor">${ext === 'jsx' ? 'JSX' : 'JS'}</text>
      </svg>`
    };

  /* ── PDF ── */
  if (ext === 'pdf' || m === 'application/pdf')
    return {
      label: 'PDF', color: '#ef4444',
      svg: `<svg viewBox="0 0 48 48" fill="none" xmlns="http://www.w3.org/2000/svg">
        <rect width="48" height="48" rx="10" fill="rgba(239,68,68,0.12)"/>
        <path d="M13 8h16l8 8v24a2 2 0 0 1-2 2H13a2 2 0 0 1-2-2V10a2 2 0 0 1 2-2z" stroke="#ef4444" stroke-width="2"/>
        <path d="M29 8v8h8" stroke="#ef4444" stroke-width="2" stroke-linecap="round"/>
        <text x="24" y="34" text-anchor="middle" font-family="monospace" font-weight="700" font-size="9" fill="#ef4444">PDF</text>
      </svg>`
    };

  /* ── ZIP / Archive ── */
  if (['zip','rar','7z','tar','gz','bz2','xz','lz','lzma'].includes(ext))
    return {
      label: ext.toUpperCase(), color: '#ffffff',
      svg: `<svg viewBox="0 0 48 48" fill="none" xmlns="http://www.w3.org/2000/svg">
        <rect width="48" height="48" rx="10" fill="rgba(255, 255, 255,0.12)"/>
        <rect x="12" y="16" width="24" height="20" rx="3" stroke="#ffffff" stroke-width="2"/>
        <path d="M12 22h24" stroke="#ffffff" stroke-width="2"/>
        <path d="M12 28h24" stroke="#ffffff" stroke-width="1.4" opacity=".5"/>
        <rect x="20" y="8" width="8" height="8" rx="2" stroke="#ffffff" stroke-width="2"/>
        <line x1="24" y1="8" x2="24" y2="16" stroke="#ffffff" stroke-width="2"/>
        <line x1="21" y1="11" x2="27" y2="11" stroke="#ffffff" stroke-width="1.5" opacity=".6"/>
        <line x1="21" y1="13" x2="27" y2="13" stroke="#ffffff" stroke-width="1.5" opacity=".6"/>
      </svg>`
    };

  /* ── Word / DOC ── */
  if (['doc','docx'].includes(ext) || m.includes('msword') || m.includes('wordprocessingml'))
    return {
      label: 'DOCX', color: '#ffffff',
      svg: `<svg viewBox="0 0 48 48" fill="none" xmlns="http://www.w3.org/2000/svg">
        <rect width="48" height="48" rx="10" fill="rgba(255, 255, 255,0.12)"/>
        <path d="M13 8h16l8 8v24a2 2 0 0 1-2 2H13a2 2 0 0 1-2-2V10a2 2 0 0 1 2-2z" stroke="#ffffff" stroke-width="2"/>
        <path d="M29 8v8h8" stroke="#ffffff" stroke-width="2" stroke-linecap="round"/>
        <line x1="16" y1="26" x2="32" y2="26" stroke="#ffffff" stroke-width="2" stroke-linecap="round"/>
        <line x1="16" y1="31" x2="28" y2="31" stroke="#ffffff" stroke-width="2" stroke-linecap="round" opacity=".6"/>
        <text x="24" y="23" text-anchor="middle" font-family="sans-serif" font-weight="800" font-size="8" fill="#ffffff">W</text>
      </svg>`
    };

  /* ── Excel / CSV / Spreadsheet ── */
  if (['xls','xlsx','csv','ods'].includes(ext) || m.includes('spreadsheet') || m.includes('excel') || m === 'text/csv')
    return {
      label: ext.toUpperCase(), color: '#16a34a',
      svg: `<svg viewBox="0 0 48 48" fill="none" xmlns="http://www.w3.org/2000/svg">
        <rect width="48" height="48" rx="10" fill="rgba(22,163,74,0.12)"/>
        <rect x="9" y="14" width="30" height="22" rx="3" stroke="#16a34a" stroke-width="2"/>
        <line x1="9" y1="22" x2="39" y2="22" stroke="#16a34a" stroke-width="1.5"/>
        <line x1="9" y1="29" x2="39" y2="29" stroke="#16a34a" stroke-width="1.5" opacity=".6"/>
        <line x1="21" y1="14" x2="21" y2="36" stroke="#16a34a" stroke-width="1.5" opacity=".7"/>
        <line x1="30" y1="14" x2="30" y2="36" stroke="#16a34a" stroke-width="1.5" opacity=".5"/>
      </svg>`
    };

  /* ── Python ── */
  if (ext === 'py' || m === 'text/x-python')
    return {
      label: 'PY', color: '#ffffff',
      svg: `<svg viewBox="0 0 48 48" fill="none" xmlns="http://www.w3.org/2000/svg">
        <rect width="48" height="48" rx="10" fill="rgba(255, 255, 255,0.10)"/>
        <path d="M18 10h8a4 4 0 0 1 4 4v4H18a4 4 0 0 1-4-4v-2a2 2 0 0 1 2-2z" fill="#ffffff"/>
        <path d="M18 38h8a4 4 0 0 0 4-4v-4H18a4 4 0 0 0-4 4v2a2 2 0 0 0 2 2z" fill="#eab308"/>
        <circle cx="22" cy="16" r="1.5" fill="white"/>
        <circle cx="26" cy="32" r="1.5" fill="white"/>
      </svg>`
    };

  /* ── JSON ── */
  if (ext === 'json' || m === 'application/json')
    return {
      label: 'JSON', color: '#f59e0b',
      svg: `<svg viewBox="0 0 48 48" fill="none" xmlns="http://www.w3.org/2000/svg">
        <rect width="48" height="48" rx="10" fill="rgba(245,158,11,0.12)"/>
        <text x="10" y="30" font-family="monospace" font-weight="700" font-size="18" fill="#f59e0b">{}</text>
        <text x="10" y="20" font-family="monospace" font-size="9" fill="#f59e0b" opacity=".7">"key":</text>
      </svg>`
    };

  /* ── CSS / SCSS ── */
  if (['css','scss','sass','less'].includes(ext))
    return {
      label: ext.toUpperCase(), color: '#ffffff',
      svg: `<svg viewBox="0 0 48 48" fill="none" xmlns="http://www.w3.org/2000/svg">
        <rect width="48" height="48" rx="10" fill="rgba(255, 255, 255,0.12)"/>
        <rect x="10" y="10" width="28" height="28" rx="5" fill="#ffffff"/>
        <text x="24" y="30" text-anchor="middle" font-family="monospace" font-weight="800" font-size="11" fill="white">CSS</text>
      </svg>`
    };

  /* ── Markdown ── */
  if (['md','mdx','markdown'].includes(ext))
    return {
      label: 'MD', color: '#767676',
      svg: `<svg viewBox="0 0 48 48" fill="none" xmlns="http://www.w3.org/2000/svg">
        <rect width="48" height="48" rx="10" fill="rgba(118, 118, 118,0.12)"/>
        <path d="M8 14h32v20H8z" stroke="#767676" stroke-width="2" rx="3"/>
        <text x="24" y="29" text-anchor="middle" font-family="monospace" font-weight="700" font-size="11" fill="#767676">M↓</text>
      </svg>`
    };

  /* ── Plain Text / TXT / LOG ── */
  if (['txt','log','ini','cfg','conf'].includes(ext) || m === 'text/plain')
    return {
      label: ext.toUpperCase() || 'TXT', color: '#a6a6a6',
      svg: `<svg viewBox="0 0 48 48" fill="none" xmlns="http://www.w3.org/2000/svg">
        <rect width="48" height="48" rx="10" fill="rgba(166, 166, 166,0.10)"/>
        <path d="M13 8h16l8 8v24a2 2 0 0 1-2 2H13a2 2 0 0 1-2-2V10a2 2 0 0 1 2-2z" stroke="#a6a6a6" stroke-width="2"/>
        <path d="M29 8v8h8" stroke="#a6a6a6" stroke-width="2" stroke-linecap="round"/>
        <line x1="16" y1="22" x2="32" y2="22" stroke="#a6a6a6" stroke-width="1.8" stroke-linecap="round"/>
        <line x1="16" y1="27" x2="32" y2="27" stroke="#a6a6a6" stroke-width="1.8" stroke-linecap="round" opacity=".7"/>
        <line x1="16" y1="32" x2="26" y2="32" stroke="#a6a6a6" stroke-width="1.8" stroke-linecap="round" opacity=".5"/>
      </svg>`
    };

  /* ── Default / unknown ── */
  return {
    label: (ext || 'FILE').toUpperCase(), color: '#ffffff',
    svg: `<svg viewBox="0 0 48 48" fill="none" xmlns="http://www.w3.org/2000/svg">
      <rect width="48" height="48" rx="10" fill="rgba(255, 255, 255,0.10)"/>
      <path d="M13 8h16l8 8v24a2 2 0 0 1-2 2H13a2 2 0 0 1-2-2V10a2 2 0 0 1 2-2z" stroke="#ffffff" stroke-width="2"/>
      <path d="M29 8v8h8" stroke="#ffffff" stroke-width="2" stroke-linecap="round"/>
      <line x1="16" y1="24" x2="32" y2="24" stroke="#ffffff" stroke-width="1.8" stroke-linecap="round" opacity=".6"/>
      <line x1="16" y1="30" x2="28" y2="30" stroke="#ffffff" stroke-width="1.8" stroke-linecap="round" opacity=".4"/>
    </svg>`
  };
}

/* export so feed.js can use it too */
export { getFileTypeInfo };

/* ── FIX: Object URL ni tozalash helper ──────────────────────────────── */
function revokeObjUrl() {
  if (state._objUrl) { URL.revokeObjectURL(state._objUrl); state._objUrl = null; }
  state._selMediaW = null;
  state._selMediaH = null;
}

/* Rasm/video tanlanganda haqiqiy o'lchamini (width/height) o'lchab olamiz —
   shu orqali feed'da post-card media joyi hali yuklanmasdan turib ham
   TO'G'RI aspect-ratio bilan ochilib turadi (blur bilan), layout sakramaydi. */
function _measureSelectedMedia(file, objUrl) {
  state._selMediaW = null;
  state._selMediaH = null;
  if (file.type.startsWith('image')) {
    const img = new Image();
    img.onload = () => {
      // Foydalanuvchi shu orada faylni almashtirgan/tozalagan bo'lishi mumkin
      if (state._objUrl !== objUrl) return;
      state._selMediaW = img.naturalWidth  || null;
      state._selMediaH = img.naturalHeight || null;
    };
    img.src = objUrl;
  } else if (file.type.startsWith('video')) {
    const vid = document.createElement('video');
    vid.preload = 'metadata';
    vid.onloadedmetadata = () => {
      if (state._objUrl !== objUrl) return;
      state._selMediaW = vid.videoWidth  || null;
      state._selMediaH = vid.videoHeight || null;
    };
    vid.src = objUrl;
  }
}

/* ── Button enable/disable check ────────────────────────────────────── */
function refreshPostBtn() {
  const hasText = !!($('captionInput').value.trim());
  const hasFile = !!state.selFile;
  $('uploadBtn').disabled = !(hasText || hasFile);
}

/* ── Reset ───────────────────────────────────────────────────────────── */
export function resetUpload() {
  revokeObjUrl();
  state.selFile = null;
  $('fileInput').value = '';
  $('previewArea').style.display = 'none';
  $('previewArea').innerHTML = '';
  $('captionInput').value = '';
  $('uploadBtn').disabled = true;
  $('uploadBtn').textContent = 'Yuklash';
  $('sizeWarn').textContent = '';
  hideProgress();
}

/* ── Progress helpers ────────────────────────────────────────────────── */
function showProgress(pct) {
  const bar   = $('uploadProgress');
  const fill  = $('uploadProgressFill');
  const label = $('uploadProgressPct');
  if (!bar) return;
  bar.classList.add('active');
  fill.style.width = pct + '%';
  label.textContent = pct.toFixed(1) + '%';
}

function hideProgress() {
  const bar = $('uploadProgress');
  if (bar) bar.classList.remove('active');
  const fill = $('uploadProgressFill');
  if (fill) fill.style.width = '0%';
}

/* ── File pick ───────────────────────────────────────────────────────── */
export function pickFile(f) {
  if (f.size > MAX_FILE) {
    $('sizeWarn').textContent = `File ${fmtSz(f.size)} — limit 50 MB`;
    toast('Fayl hajmi 50 MB dan oshmasligi kerak', 'error');
    return;
  }
  $('sizeWarn').textContent = '';
  revokeObjUrl();
  state.selFile = f;
  state._objUrl = URL.createObjectURL(f);
  _measureSelectedMedia(f, state._objUrl);
  $('uploadBtn').disabled = false;
  $('previewArea').style.display = 'block';

  if (f.type.startsWith('image')) {
    $('previewArea').innerHTML = `<div class="preview-wrap"><img src="${state._objUrl}"><button class="preview-clear" data-action="clear-file">
      <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></svg>
    </button></div>`;
  } else if (f.type.startsWith('video')) {
    $('previewArea').innerHTML = `<div class="preview-wrap"><video class="max-h-150px w-full brr-10px" src="${state._objUrl}" controls muted></video><button class="preview-clear" data-action="clear-file">
      <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></svg>
    </button></div>`;
  } else {
    const info = getFileTypeInfo(f.name, f.type);
    $('previewArea').innerHTML = `<div class="preview-file">
      <div class="preview-file-icon w-44px h-44px flex-shrink-0">${info.svg}</div>
      <div class="flex-1 min-w-0">
        <div class="fs-13px fw-500 ws-nowrap overflow-hidden text-ellipsis">${esc(f.name)}</div>
        <div class="fs-11px c-text3-theme mt-2px">${info.label} · ${fmtSz(f.size)}</div>
      </div>
      <button class="bg-transparent border-none c-text3-theme cursor-pointer d-flex items-center flex-shrink-0" data-action="clear-file">
        <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></svg>
      </button>
    </div>`;
  }
  refreshPostBtn();
}

/* ── Caption input → enable/disable Post btn ─────────────────────────── */
$('captionInput').addEventListener('input', refreshPostBtn);

/* ── Preview clear ───────────────────────────────────────────────────── */
$('previewArea').addEventListener('click', e => {
  if (e.target.closest('[data-action="clear-file"]')) clearFile();
});

function clearFile() {
  revokeObjUrl();
  state.selFile = null;
  $('previewArea').style.display = 'none';
  $('previewArea').innerHTML = '';
  $('fileInput').value = '';
  refreshPostBtn();
}

/* ── Yuklash / Post ───────────────────────────────────────────────────── */
/* ── Float bar helpers ───────────────────────────────────────────────── */
function floatBarShow(name) {
  const bar = $('uploadFloatBar');
  if (!bar) return;
  $('ufbName').textContent = name || 'Yuklanmoqda...';
  $('ufbFill').style.width = '0%';
  $('ufbFill').classList.remove('indeterminate');
  $('ufbPct').textContent  = '0%';
  bar.style.display = 'flex';
}

function floatBarUpdate(pct) {
  const fill = $('ufbFill');
  const pctEl = $('ufbPct');
  if (!fill) return;
  if (pct >= 95) {
    /* 90%+ da qotib qolmasin — indeterminate animatsiya */
    fill.classList.add('indeterminate');
    pctEl.textContent = 'Tugatilmoqda...';
  } else {
    fill.classList.remove('indeterminate');
    fill.style.width = pct + '%';
    pctEl.textContent = Math.round(pct) + '%';
  }
}

function floatBarDone(success) {
  const bar  = $('uploadFloatBar');
  const icon = bar?.querySelector('.ufb-icon');
  const fill = $('ufbFill');
  if (!bar) return;
  fill?.classList.remove('indeterminate');
  if (fill) fill.style.width = '100%';
  $('ufbPct').textContent = '100%';
  $('ufbName').textContent = success ? 'Yuklandi!' : 'Yuklash amalga oshmadi';
  if (icon) {
    icon.classList.add('done');
    icon.innerHTML = success
      ? '<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><polyline points="20 6 9 17 4 12"/></svg>'
      : '<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></svg>';
  }
  setTimeout(() => {
    if (bar) bar.style.display = 'none';
    if (icon) { icon.classList.remove('done'); icon.innerHTML = '<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><line x1="12" y1="19" x2="12" y2="5"/><polyline points="5 12 12 5 19 12"/></svg>'; }
  }, 2500);
}

/* ── Yuklash / Post ───────────────────────────────────────────────────── */
$('uploadBtn').onclick = async () => {
  const caption      = $('captionInput').value.trim();
  const isPublic     = true; // yopiq tarmoq: yangi postlar hamma tasdiqlangan a'zoga ko'rinadi
  if (!state.me) return;
  if (!caption && !state.selFile) return;

  $('uploadBtn').disabled    = true;
  $('uploadBtn').textContent = 'Yuklanmoqda…';

  /* Fayl bo'lsa overlay ni darhol yopamiz — foydalanuvchi reels ko'ra olsin */
  const hasFile = !!state.selFile;
  if (hasFile) {
    $('uploadOverlay').classList.remove('show');
    unlockScroll();
    const shortName = state.selFile.name.length > 28
      ? state.selFile.name.slice(0, 26) + '…'
      : state.selFile.name;
    floatBarShow(shortName);
  }

  try {
    const { data: ud } = await sb.from('profiles').select('full_name').eq('id', state.me.uid).maybeSingle();
    let mediaPath = null;
    let mediaUrl  = null;
    let mediaType = null;
    let fileName  = null;
    let fileSize  = null;

    /* ── Private / Public uchun Firestore ── */
    if (hasFile) {
      const file = state.selFile;

      let simPct = 0;
      let lastTick = Date.now();
      const simInterval = setInterval(() => {
        lastTick = Date.now();
        const step = Math.max(0.3, (3 - (file.size / (10 * 1024 * 1024))) * Math.random());
        simPct = Math.min(simPct + step, 88);
        floatBarUpdate(simPct);
      }, 200);

      const result = await uploadViaController(file, 'posts');

      clearInterval(simInterval);
      floatBarUpdate(100);

      mediaPath    = result.path;
      mediaUrl     = result.url;
      mediaType    = file.type;
      fileName     = file.name;
      fileSize     = file.size;
    }

    const { error: postErr } = await sb.from('posts').insert({
      user_id:        state.me.uid,
      user_full_name: ud?.full_name || state.me.displayName || 'Foydalanuvchi',
      text:           caption || null,
      media_path:     mediaPath,
      media_type:     mediaType,
      media_width:    hasFile ? (state._selMediaW || null) : null,
      media_height:   hasFile ? (state._selMediaH || null) : null,
      file_name:      fileName,
      file_size:      fileSize,
      is_public:      !!isPublic,
    });
    if (postErr) {
      // Post yozilmadi — yuklangan faylni yetim qoldirmaymiz
      if (mediaPath) sb.storage.from('media').remove([mediaPath]).catch(() => {});
      throw postErr;
    }

    revokeObjUrl();

    if (hasFile) {
      floatBarDone(true);
    } else {
      toast('Yuklandi!', 'success');
      $('uploadOverlay').classList.remove('show');
      unlockScroll();
    }
    resetUpload();

  } catch (err) {
    if (hasFile) {
      floatBarDone(false);
      toast('Yuklash amalga oshmadi: ' + (err.message || 'Noma\'lum xatolik'), 'error');
    } else {
      toast('Xatolik: ' + (err.message || 'Noma\'lum xatolik'), 'error');
      $('uploadOverlay').classList.remove('show');
      unlockScroll();
    }
    resetUpload();
  }
};

/* ── Composer avatar (joriy foydalanuvchi) ─────────────────────────────── */
function loadComposerAvi() {
  const box = $('composerAvi');
  if (!box || !state.me) return;
  Promise.resolve(sb.from('profiles').select('full_name,avatar').eq('id', state.me.uid).maybeSingle())
    .then(({ data }) => {
      const av = data?.avatar || defAvi(data?.full_name || 'U');
      box.innerHTML = `<img src="${av}" onerror="this.style.display='none'">`;
    }).catch(() => {});
}

/* ── Overlay open/close ──────────────────────────────────────────────── */
function openComposer() {
  $('uploadOverlay').classList.add('show');
  lockScroll();
  resetUpload();
  loadComposerAvi();
}
$('createBtn').onclick     = openComposer;
$('hdrNewPostBtn').onclick = openComposer;
$('cancelUpload').onclick = () => { $('uploadOverlay').classList.remove('show'); unlockScroll(); resetUpload(); };
$('uploadOverlay').onclick = e => {
  if (e.target === $('uploadOverlay')) { $('uploadOverlay').classList.remove('show'); unlockScroll(); resetUpload(); }
};

/* ── File input / drop / paste ───────────────────────────────────────── */
$('uploadDrop').onclick = () => $('fileInput').click();
$('fileInput').onchange = e => { if (e.target.files[0]) pickFile(e.target.files[0]); };

$('uploadDrop').addEventListener('dragover', e => {
  e.preventDefault();
  $('uploadDrop').classList.add('drag-over');
});
$('uploadDrop').addEventListener('dragleave', () => $('uploadDrop').classList.remove('drag-over'));
$('uploadDrop').addEventListener('drop', e => {
  e.preventDefault();
  $('uploadDrop').classList.remove('drag-over');
  const f = e.dataTransfer.files[0]; if (f) pickFile(f);
});

window.addEventListener('paste', e => {
  for (const item of (e.clipboardData?.items || [])) {
    if (item.kind === 'file') {
      const f = item.getAsFile();
      if (f) { pickFile(f); $('uploadOverlay').classList.add('show'); lockScroll(); break; }
    }
  }
});